package diagram.q01_animal;

public class Animal {
	private String name;
}
