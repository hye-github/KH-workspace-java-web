package diagram.q01_animal;

public class Dog extends Animal{
	
}
