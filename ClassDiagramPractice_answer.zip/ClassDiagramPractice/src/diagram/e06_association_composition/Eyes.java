package diagram.e06_association_composition;

public class Eyes {

}
