package diagram.e03_realization;

public interface USBType {
	
	void bootup(); // 컴퓨터와 연결할 때 사용할 함수
	
}
