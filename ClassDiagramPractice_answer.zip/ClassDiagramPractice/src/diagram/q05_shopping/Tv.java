package diagram.q05_shopping;

public class Tv extends Item{
	
}
