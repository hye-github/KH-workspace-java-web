package diagram.q02_car;
public class Frame {

}
