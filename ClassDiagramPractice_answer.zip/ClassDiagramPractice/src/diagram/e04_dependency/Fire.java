package diagram.e04_dependency;

public class Fire {

}
