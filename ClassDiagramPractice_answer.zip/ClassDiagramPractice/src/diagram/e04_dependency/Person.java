package diagram.e04_dependency;

public class Person {
	private Fire f = new Fire();
	public void cooking(Fire f) {
		
	}
	
	public void cooking2() {
		Fire f = new Fire();
	}
	
	
	
	
}
