package diagram.e03_realization;

public class SmartPhone implements USBType{
	
	@Override
	public void bootup() {
		// TODO Auto-generated method stub	
	}
}
