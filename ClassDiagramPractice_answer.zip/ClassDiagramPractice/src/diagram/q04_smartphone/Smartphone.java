package diagram.q04_smartphone;
public class Smartphone implements Calculator, Camera, MultiMedia, Telephone{

	@Override
	public void call() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sms() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void youtube() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void movie() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void music() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void takePicture() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calculate() {
		// TODO Auto-generated method stub
		
	}
	
}
