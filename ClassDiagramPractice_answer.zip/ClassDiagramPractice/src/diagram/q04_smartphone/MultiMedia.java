package diagram.q04_smartphone;

public interface MultiMedia {
	public void youtube();
	public void movie();
	public void music();
}
