package diagram.q04_smartphone;
public interface Camera {
	public void takePicture();
}
