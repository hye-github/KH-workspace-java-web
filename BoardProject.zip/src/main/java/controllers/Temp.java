package controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Temp {
	public static void main(String[] args) throws Exception{
//		main은 톰캣 프로그램이 가지고 있다.
//		이렇게 main을 만들면 톰캣(웹 어플리케이션)을 실행할지, 이 java 네이티브 어플리케이션를 실행할지 물어본다.
//		테스트용으로 임시로 만든 코드이다.
		
		System.out.println("Hello World");
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String id = "kh";
		String pw = "kh";
		
		String sql = "insert into board values(board_seq.nextval,?,?,?,sysdate,0)";
		
		Connection con = DriverManager.getConnection(url, id, pw);
		PreparedStatement pstat = con.prepareCall(sql);
		
		for(int i = 1;i<145;i++) {
			pstat.setString(1, "Test"+i);
			pstat.setString(2, "Title"+i);
			pstat.setString(3, "Contents"+i);
			pstat.executeUpdate();
			Thread.sleep((long)(Math.random()*(700-200+1)+200));
			System.out.println(i+" 번째 데이터 : Test" + i);
		}
				
		// pstat.addBatch();
		
		con.commit();
		con.close();
		
	}
}
