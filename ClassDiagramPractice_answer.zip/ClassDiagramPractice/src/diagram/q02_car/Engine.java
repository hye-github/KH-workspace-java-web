package diagram.q02_car;
public class Engine {

}
