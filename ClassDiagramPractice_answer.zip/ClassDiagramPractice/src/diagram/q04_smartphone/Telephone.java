package diagram.q04_smartphone;
public interface Telephone {
	public void call();
	public void sms();
}
