package diagram.e05_association_aggregation;

public class Watch {

}
