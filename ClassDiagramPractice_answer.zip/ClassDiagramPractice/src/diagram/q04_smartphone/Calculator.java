package diagram.q04_smartphone;

public interface Calculator {
	public void calculate();
}
