package diagram.q02_car;

public class Car {
	private Engine engine;
	private Frame frame;
	private Wheel wheel;
	
	public Car(Engine engine, Frame frame, Wheel wheel) {
		this.engine = engine;
		this.frame = frame;
		this.wheel = wheel;
	}
	
	
	
}
