package diagram.q03_vehicle;

public interface Vehicle {
	public void engineOn();
	public void engineOff();
}
