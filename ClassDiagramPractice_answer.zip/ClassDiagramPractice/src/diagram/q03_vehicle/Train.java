package diagram.q03_vehicle;

public class Train implements Vehicle{

	@Override
	public void engineOn() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void engineOff() {
		// TODO Auto-generated method stub
		
	}
	
}
