package diagram.e02_generalization;

public class Gold extends Member{

}
