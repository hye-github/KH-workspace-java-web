package diagram.e03_realization;

public class ExternalHdd implements USBType{
	
	@Override
	public void bootup() {
		// TODO Auto-generated method stub
		
	}
	
}
