package diagram.q05_shopping;

public class Calculator {
	public int calculate() {
		return 0;
	}
}
